# Customer Segmentation Using Python

## 📌 Project Overview
This project builds a customer segmentation system using transactional retail data.
Customers are grouped based on purchasing behavior to help businesses improve
marketing strategies, personalization, and customer retention.

---

## 📂 Dataset Description
The project uses the **Online Retail dataset**, which contains transactional data such as:
- Invoice number
- Product details
- Quantity purchased
- Unit price
- Customer ID
- Country
- Invoice date

Each row represents a product purchased in a transaction.

---

## 🎯 Business Objective
The goal of this project is to:
- Identify high-value customers
- Detect at-risk customers
- Understand customer purchasing patterns
- Enable targeted marketing strategies

---

## 🛠 Tools & Technologies
- Python
- Pandas
- NumPy
- Matplotlib
- Seaborn
- Scikit-learn
- Jupyter Notebook

---

## 🔄 Project Workflow
1. Data understanding
2. Data cleaning & preprocessing
3. Exploratory data analysis (EDA)
4. Feature engineering using RFM model
5. Feature scaling
6. K-Means clustering
7. Business interpretation of customer segments
8. Dashboard & visualization

---

## 📊 Customer Segmentation Approach
Customer segmentation was performed using the **RFM model**:
- **Recency**: Days since last purchase
- **Frequency**: Number of purchases
- **Monetary**: Total spending

K-Means clustering was applied to the scaled RFM features to identify distinct customer groups.

---

## 🧠 Key Insights
- Customer spending is highly skewed
- A small group of customers contributes a large portion of revenue
- Customers can be classified into segments such as loyal, at-risk, new, and regular
- Targeted strategies can significantly improve customer retention

---

## 📈 Dashboard & Visualization
Visualizations were created to show:
- Customer distribution across segments
- Revenue contribution by segment
- Behavioral differences using RFM metrics

---

## ✅ Conclusion
This project demonstrates an end-to-end customer segmentation pipeline,
from raw transactional data to actionable business insights.

---

## 📌 Future Enhancements
- Build an interactive dashboard using Streamlit or Power BI
- Experiment with other clustering algorithms
- Add demographic features for deeper segmentation
